# ARKAIM mobile performance and local SEO

## Scope and audit

Preserved the existing visual identity, Arabic marketing copy, services, contact
number and Instagram destination. No deployment was made. No dependency upgrades
were included; the separate vulnerability task owns those.

The original production document contained an empty root. Metadata was generic,
pinch zoom was disabled, no sitemap or LocalBusiness markup existed, images had
no responsive candidates, and all local fonts depended on Google Fonts requests.
The original mobile call/WhatsApp bar already used native links but only appeared
after JavaScript rendered it.

## Measurement

Lighthouse 13.6.0, production build served with Vite preview, mobile emulation
412 × 823 at 1.75 DPR, simulated Slow 4G (150 ms RTT, 1,638.4 Kbps throughput),
4× CPU slowdown. These are local lab results, not real-user production metrics.
Development-server results were excluded.

| Metric | Before | Final delivery build |
| --- | ---: | ---: |
| Performance | 90 | 80 |
| Accessibility | 84 | 95 |
| Best Practices | 100 | 100 |
| SEO | 100 | 100 |
| LCP | 2.8 s | 1.3 s |
| FCP | 1.4 s | 1.3 s |
| TBT | 260 ms | 850 ms |
| CLS | approximately 0 | approximately 0 |
| Speed Index | 1.7 s | 2.5 s |
| Initial JavaScript, gzip | 109.57 KB | 82.74 KB |
| Generated CSS, gzip | 18.51 KB | 10.22 KB |
| Logo file | 35,654 bytes | 1,452 bytes |

An intermediate build reached Performance 90, LCP 1.5 s and TBT 370 ms. The final
measurement above supersedes that result. **The final build did not meet the 90+
performance target and TBT regressed**, despite faster LCP and smaller initial
JavaScript. No claim is made that all speed targets were met. Further hydration
profiling is required before calling the responsiveness work complete. INP cannot
be inferred from TBT or a page-load Lighthouse run; no field INP value is available.
Accessibility 95 is an automated score, not a claim that every contrast issue on
every deferred section is resolved.

## Implemented

- Build-time streaming React pre-rendering of the header, hero, statistics,
  services and native mobile contact bar. Existing service descriptions remain
  readable and contact links work before JavaScript.
- Hydration reuses that HTML. Services activate near the viewport; lower sections
  retain their existing lazy imports and load on approach. Browser
  content-visibility avoids unnecessary offscreen layout.
- Stable section IDs and a hash-navigation coordinator reveal preceding sections
  before settling an anchor jump. This prevents a late-loading offer, coverage or
  testimonials section from pushing the contact form out of view.
- Arabic-first metadata, LocalBusiness data using existing address/coverage/hours,
  unrestricted pinch zoom and a 1200×630 social image.
- Existing cockroach, termite, rodent and bed-bug descriptions are pre-rendered
  with distinct fragment targets. Footer links now target those sections; no
  new claims or separate thin service pages were invented.
- Local Arabic/Latin variable Cairo fonts with their SIL Open Font License.
  Removed the Google Fonts stylesheet and preconnects.
- Smaller logo and 320-pixel service image variants with responsive sizes.
  Explicit dimensions reserve image space. Hero illustration remains deferred
  on phones; the actual observed LCP logo gets high priority.
- Save-Data, 2G/3G and <=4 GB device mode disables nonessential CSS motion,
  selects small service images after hydration, and avoids speculative section
  prefetching. Reduced-motion devices skip counter animations.
- Existing form controls and appearance retained. Added accessible quick-form
  names, phone keyboards/autofill, trimmed input validation, consistent full
  service labels in WhatsApp messages, and an honest handoff status. Values are
  not cleared before the customer sends the WhatsApp message.
- Removed unused root query, tooltip and toast providers from initial loading.
- A conservative service worker caches only same-origin, hashed JS/CSS URLs
  without query strings. It never intercepts HTML navigation, API requests,
  WhatsApp or other third-party traffic, so it cannot serve stale contact HTML.
  Offline navigation is deliberately not promised.

## Verification

- Website TypeScript check and production build passed.
- Static regression script checks pre-rendered copy, phone links, section IDs,
  metadata, bundle budget, sitemap shape and service-worker interception policy:
  `node artifacts/arkaim-website/verify-static.mjs`.
- Mobile browser pass: no-JS content/links, service filters, mobile menu,
  blank/invalid quick form, both valid WhatsApp handoffs, low-end mode, hashed-asset
  offline cache and exclusion of personal-data/query/navigation requests passed.
- WhatsApp requests were intercepted; **no real message was sent**.
- A deferred contact-anchor landing bug was found, fixed and retested from both
  the menu and a direct `/#contact` load. The contact section settled at the
  expected 88-pixel header offset with no duplicate IDs or console errors.
- Specific service hashes now restore the "all" category when a category filter
  had removed their destination. This final correction was type-checked but
  has not had a separate browser pass.
- Production-host compression and CDN cache headers cannot be certified from
  local Vite preview. The local document uses `Cache-Control: no-cache`.
- Existing Vite sourcemap warnings from select/label components are non-fatal.

## Deferred or deliberately unchanged

1. **Production origin:** deployment metadata reports no published website.
   The checked-in sitemap is valid but empty, not a populated SEO sitemap.
   Absolute canonical/social URLs and sitemap/robots references are generated
   when a verified HTTPS production origin is supplied as `SITE_URL` during
   build. Preview URLs are rejected. No production URL was invented.
2. **Performance score/TBT:** the final target is unmet; results are reported
   above rather than masked by the better intermediate run. The assigned
   performance task remains open; this is a partial implementation, not an
   accepted completion.
3. **Contrast:** green link text and muted labels still need visual approval
   before changing brand colors/opacity. Existing colors were not silently
   altered to increase an automated score.
4. **Embeds:** there are no live map or video iframes in the homepage to convert.
5. **Publication:** not performed. Production SEO activation, CDN compression
   and cache-header verification must follow publication on a confirmed domain.

## Changed files

All paths below are relative to `artifacts/arkaim-website/`.

| File | Reason |
| --- | --- |
| `index.html` | Real Arabic metadata, zoom, local resource priorities and LocalBusiness JSON-LD. |
| `package.json` | Run pre-rendering after the Vite build. |
| `prerender.mjs` | Stream complete first-screen/services HTML, inline CSS, and conditionally generate origin-specific SEO files. |
| `verify-static.mjs` | Static HTML/bundle/cache-policy regression checks. |
| `PERFORMANCE-REPORT.md` | Record evidence, tradeoffs, changed files and unmet targets. |
| `src/App.tsx` | Remove unused providers and supply the server router path. |
| `src/main.tsx` | Hydrate existing HTML, initialize device mode and register the safe cache. |
| `src/pages/Home.tsx` | Combine pre-rendered services with deferred lower sections and stable anchors. |
| `src/index.css` | Local fonts, narrower Tailwind scanning, reduced-motion/low-end behavior and anchor offset. |
| `src/lib/device-mode.ts` | Detect constrained devices and register the production-only service worker. |
| `src/lib/deferred-section.ts` | Activate modules on approach or explicit hash navigation. |
| `src/components/sections/HashNavigation.tsx` | Correct anchor landing after preceding deferred sections load. |
| `src/components/sections/LazySection.tsx` | Keep IDs stable, retain deferred rendering, signal completed sections. |
| `src/components/sections/Hero.tsx` | Native WhatsApp/consult links, illustration dimensions, remove unused code. |
| `src/components/sections/Navbar.tsx` | Smaller priority logo, accessible mobile menu, native hash behavior and scroll state. |
| `src/components/sections/Services.tsx` | Responsive smaller images, dimensions, service fragment targets and low-end selection. |
| `src/components/sections/QuickRequestForm.tsx` | Validation, accessible names, autofill and non-destructive handoff status. |
| `src/components/sections/ContactForm.tsx` | Consistent service labels, controlled selection, validation and handoff status. |
| `src/components/sections/Footer.tsx` | Smaller logo and specific service fragment links. |
| `src/components/sections/TrustStrip.tsx` | Meaningful static counters and reduced-motion/low-end behavior. |
| `src/components/sections/WhyUs.tsx` | Image dimensions and stable wrapper-owned section target. |
| `src/components/sections/SeasonalOffer.tsx` | Image dimensions. |
| `public/opengraph.jpg` | Resize existing artwork to 1200×630 and recompress. |
| `public/logo.webp` | Small modern-format logo. |
| `public/fonts/cairo-arabic.woff2` | Self-hosted variable Arabic subset. |
| `public/fonts/cairo-latin.woff2` | Self-hosted variable Latin subset. |
| `public/fonts/OFL.txt` | Font redistribution license. |
| `public/sitemap.xml` | Valid empty sitemap awaiting a verified production origin. |
| `public/sw.js` | Bounded hashed-asset cache excluding navigation and personal data. |
| `public/pests/small/ant.webp` | 320-pixel responsive service variant. |
| `public/pests/small/bedbug.webp` | 320-pixel responsive service variant. |
| `public/pests/small/cockroach.webp` | 320-pixel responsive service variant. |
| `public/pests/small/flea.webp` | 320-pixel responsive service variant. |
| `public/pests/small/fly.webp` | 320-pixel responsive service variant. |
| `public/pests/small/gecko.webp` | 320-pixel responsive service variant. |
| `public/pests/small/general.webp` | 320-pixel responsive service variant. |
| `public/pests/small/locust.webp` | 320-pixel responsive service variant. |
| `public/pests/small/mosquito.webp` | 320-pixel responsive service variant. |
| `public/pests/small/moth.webp` | 320-pixel responsive service variant. |
| `public/pests/small/pigeon.webp` | 320-pixel responsive service variant. |
| `public/pests/small/rat.webp` | 320-pixel responsive service variant. |
| `public/pests/small/sandfly.webp` | 320-pixel responsive service variant. |
| `public/pests/small/scorpion.webp` | 320-pixel responsive service variant. |
| `public/pests/small/silverfish.webp` | 320-pixel responsive service variant. |
| `public/pests/small/spider.webp` | 320-pixel responsive service variant. |
| `public/pests/small/termite.webp` | 320-pixel responsive service variant. |
| `public/pests/small/wasp.webp` | 320-pixel responsive service variant. |
| `public/pests/small/weevil.webp` | 320-pixel responsive service variant. |
| `public/pests/small/woodborer.webp` | 320-pixel responsive service variant. |

The project memory note was also updated with the architectural tradeoff: prefer
pre-rendered critical content plus deferred lower-page activation, not eager
hydration of every marketing section.
