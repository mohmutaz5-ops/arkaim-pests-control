import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "node:path";

export default defineConfig(({ command }) => {
  const port = command === "serve" ? Number(process.env.PORT ?? 5173) : 5173;
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error("PORT must be an integer between 1 and 65535.");
  }
  return {
    base: "/",
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: { "@": path.resolve(import.meta.dirname, "src") },
      dedupe: ["react", "react-dom"],
    },
    root: import.meta.dirname,
    build: { outDir: "dist/public", emptyOutDir: true },
    server: { port, strictPort: true, host: "0.0.0.0" },
    preview: { port, host: "0.0.0.0" },
  };
});
