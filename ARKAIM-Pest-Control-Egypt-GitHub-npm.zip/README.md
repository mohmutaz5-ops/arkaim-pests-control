# ARKAIM Pest Control Egypt

This is the standalone website source for GitHub or Vercel. The full site source and public assets are included. It has no separate API or database requirement and does not require a Replit account.

## Local use

Use Node.js 22.12+ or 24 and npm, from the extracted folder:

```sh
npm install
npm run build
npm run verify
npm run serve
```

The static production output is in `dist/public`. For development use `npm run dev`. For a reproducible install from the lockfile use `npm ci`.

## GitHub and Vercel

Upload the extracted files, including the dotfiles and package-lock.json, to the root of your GitHub repository. Import that repository from Vercel, use the repository root, and leave command overrides disabled so that Vercel uses `vercel.json`.

Optionally set the public build variable `SITE_URL` to the verified HTTPS production origin to generate absolute social metadata and a populated sitemap. It is not needed for the build to run. Forms open WhatsApp with a prepared message; visitors still tap Send inside WhatsApp.
