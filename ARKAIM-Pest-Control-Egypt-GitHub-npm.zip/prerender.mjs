import { createServer } from "vite";
import react from "@vitejs/plugin-react";
import { createElement } from "react";
import { renderToPipeableStream, renderToStaticMarkup } from "react-dom/server";
import { PassThrough } from "node:stream";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.dirname(fileURLToPath(import.meta.url));
const server = await createServer({
  configFile: false,
  root,
  cacheDir: path.join(root, "node_modules/.vite-prerender"),
  optimizeDeps: { noDiscovery: true, include: [] },
  base: "/",
  plugins: [react()],
  resolve: { alias: { "@": path.join(root, "src") }, dedupe: ["react", "react-dom"] },
  server: { middlewareMode: true, hmr: false },
  appType: "custom",
});
try {
  const { default: App } = await server.ssrLoadModule("/src/App.tsx");
  const markup = await new Promise((resolve, reject) => {
    const output = new PassThrough();
    const chunks = [];
    output.on("data", chunk => chunks.push(chunk));
    output.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    output.on("error", reject);
    const stream = renderToPipeableStream(createElement(App), {
      onAllReady() { stream.pipe(output); },
      onError(error) { reject(error); },
    });
  });
  const output = path.join(root, "dist/public/index.html");
  let html = await readFile(output, "utf8");
  // Inline the generated stylesheet: no render-blocking CSS round-trip on 3G.
  html = await (async () => {
    const styles = [...html.matchAll(/<link rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/g)];
    for (const match of styles) {
      const cssPath = path.join(root, "dist/public", match[1].replace(/^\//, ""));
      const css = await readFile(cssPath, "utf8");
      html = html.replace(match[0], `<style>${css}</style>`);
    }
    return html;
  })();
  // Vercel serves 404.html with a real 404 instead of hydrating the home page on unknown URLs.
  const { default: NotFound } = await server.ssrLoadModule("/src/pages/not-found.tsx");
  const notFound = html
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "")
    .replace(/<link[^>]*rel="modulepreload"[^>]*>/gi, "")
    .replace(/<link[^>]*rel="preload"[^>]*as="image"[^>]*>/gi, "")
    .replace(/<title>[^<]*<\/title>/, '<title>404 | أركيم</title>')
    .replace(/<meta name="robots"[^>]*>/, '<meta name="robots" content="noindex" />')
    .replace('<div id="root"></div>', () => `<div id="root">${renderToStaticMarkup(createElement(NotFound))}</div>`);
  await writeFile(path.join(root, "dist/public/404.html"), notFound);
  html = html.replace('<div id="root"></div>', `<div id="root">${markup}</div>`);
  if (!html.includes("الأمان الحقيقي يبدأ") || !html.includes('href="tel:01080808564"')) {
    throw new Error("Pre-render verification failed: missing headline or call link");
  }
  await writeFile(output, html);
  // Never guess a production origin. Supplying SITE_URL at build time enables
  // absolute social metadata, a canonical URL, and a populated sitemap.
  const siteUrl = process.env.SITE_URL;
  if (siteUrl) {
    const url = new URL(siteUrl);
    if (url.protocol !== "https:" || url.hostname.endsWith(".replit.dev")) {
      throw new Error("SITE_URL must be the verified HTTPS production URL, not a preview URL.");
    }
    if (url.username || url.password || url.search || url.hash || url.pathname !== "/") {
      throw new Error("SITE_URL must contain only the verified origin, without credentials, query, fragment, or path.");
    }
    const origin = url.origin;
    html = html.replaceAll('content="/opengraph.jpg"', `content="${origin}/opengraph.jpg"`);
    html = html.replace("</head>", `<link rel="canonical" href="${origin}/" /><meta property="og:url" content="${origin}/" /></head>`);
    await writeFile(output, html);
    await writeFile(path.join(root, "dist/public/sitemap.xml"), `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${origin}/</loc></url></urlset>`);
    await writeFile(path.join(root, "dist/public/robots.txt"), `User-agent: *\nAllow: /\nSitemap: ${origin}/sitemap.xml\n`);
  } else {
    console.warn("SITE_URL not set: canonical URL and sitemap entries deferred until the production domain is verified.");
  }
  console.log("Pre-rendered the homepage, services, and contact links.");
} finally {
  await server.close();
}
