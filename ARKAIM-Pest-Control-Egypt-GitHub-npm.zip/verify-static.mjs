import assert from "node:assert/strict";
import { access, readFile, readdir } from "node:fs/promises";
import { gzipSync } from "node:zlib";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { runInNewContext } from "node:vm";

const root = path.dirname(fileURLToPath(import.meta.url));
const output = path.join(root, "dist/public");
const html = await readFile(path.join(output, "index.html"), "utf8");
assert(html.includes("الأمان الحقيقي يبدأ"));
assert(html.includes('href="tel:01080808564"'));
assert(html.includes('href="https://wa.me/201080808564"'));
assert(!html.includes("maximum-scale"));
assert(!html.includes("built on Replit"));
assert(!html.includes("fonts.googleapis.com"));
assert(html.includes('type="application/ld+json"'));
assert(html.includes("<style>"));
for (const id of ["cockroaches", "termites", "rodents", "bed-bugs"]) {
  assert(html.includes(`id="${id}"`), `Missing pre-rendered service: ${id}`);
}
const ids = [...html.matchAll(/\sid="([^"]+)"/g)].map(match => match[1]);
assert.equal(new Set(ids).size, ids.length, "Duplicate HTML ids");
const assets = await readdir(path.join(output, "assets"));
const notFound = await readFile(path.join(output, "404.html"), "utf8");
assert(notFound.includes("الصفحة غير موجودة (404)"));
assert(notFound.includes('href="/"'));
assert(!notFound.includes("<script"), "The static 404 page should not run JavaScript");
const compiled = await Promise.all(assets.map(name => readFile(path.join(output, "assets", name), "utf8")));
const mediaUrls = new Set([html, ...compiled].flatMap(source =>
  [...source.matchAll(/["'(](\/(?:fonts\/|pests\/)?[\w/-]+\.(?:webp|png|jpg|woff2|svg))(?=["') ])/g)].map(match => match[1]),
));
for (const url of mediaUrls) {
  await access(path.join(output, url.slice(1)));
  if (/^\/pests\/[^/]+\.webp$/.test(url)) {
    await access(path.join(output, url.replace("/pests/", "pests/small/")));
  }
}
assert(mediaUrls.size >= 20, "Expected to verify the compiled media URLs");
const entry = assets.find(name => /^index-.*\.js$/.test(name));
assert(entry, "Missing initial JavaScript bundle");
const bytes = gzipSync(await readFile(path.join(output, "assets", entry))).length;
assert(bytes < 170_000, `Initial JavaScript exceeds budget: ${bytes}`);
const sitemap = await readFile(path.join(output, "sitemap.xml"), "utf8");
assert(sitemap.includes('<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"'));

// Test interception policy without making a network request.
const events = new Map();
runInNewContext(await readFile(path.join(root, "public/sw.js"), "utf8"), {
  URL,
  self: {
    location: { origin: "https://example.test" },
    addEventListener: (name, handler) => events.set(name, handler),
  },
  caches: { open: () => new Promise(() => {}) },
});
function request(url, mode = "cors", method = "GET") {
  let handled = false;
  events.get("fetch")({
    request: { url, mode, method },
    respondWith() { handled = true; },
  });
  return handled;
}
assert(request("https://example.test/assets/index-abc123.js"));
assert(!request("https://example.test/", "navigate"));
assert(!request("https://example.test/index.html"));
assert(!request("https://example.test/assets/index-abc123.js?text=private"));
assert(!request("https://wa.me/201080808564?text=private"));
assert(!request("https://example.test/api/request", "cors", "POST"));
console.log(`Static HTML, ${mediaUrls.size} media URLs, 404 page, and cache-policy checks passed. Initial JS: ${(bytes / 1000).toFixed(1)} KB gzip.`);
