import { Switch, Route, Router as WouterRouter } from "wouter";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")} ssrPath="/">
          <Router />
        </WouterRouter>
  );
}

export default App;
