import { isLowEndDevice } from "./device-mode";

export const serviceAnchors = ["cockroaches", "termites", "rodents", "bed-bugs"];

export function currentAnchorId() {
  try { return decodeURIComponent(window.location.hash.slice(1)); } catch { return ""; }
}

export function isAtOrBeforeHash(element: Element) {
  const id = currentAnchorId();
  const target = document.getElementById(id) ??
    (serviceAnchors.includes(id) ? document.getElementById("services") : null);
  return Boolean(target && (element.contains(target) ||
    (element.compareDocumentPosition(target) & Node.DOCUMENT_POSITION_FOLLOWING)));
}

// React keeps the server-rendered Suspense content visible while its module is
// pending. Load code on approach, not all at once during the initial hydration.
export function onSectionApproach(id: string): Promise<void> {
  if (typeof window === "undefined" || !("IntersectionObserver" in window)) {
    return Promise.resolve();
  }
  return new Promise((resolve) => {
    const element = document.querySelector(`[data-deferred-section="${id}"]`);
    if (!element) { resolve(); return; }
    const finish = () => {
      observer.disconnect();
      window.removeEventListener("hashchange", reveal);
      window.removeEventListener("arkaim:reveal", reveal);
      resolve();
    };
    const reveal = () => { if (isAtOrBeforeHash(element)) finish(); };
    const observer = new IntersectionObserver((entries) => {
      if (entries.some(entry => entry.isIntersecting)) {
        finish();
      }
    }, { rootMargin: isLowEndDevice() ? "0px" : "250px" });
    observer.observe(element);
    window.addEventListener("hashchange", reveal);
    window.addEventListener("arkaim:reveal", reveal);
    reveal();
  });
}
