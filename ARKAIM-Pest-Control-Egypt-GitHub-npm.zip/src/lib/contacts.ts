export const INSTAGRAM_URL = "https://www.instagram.com/arkeem.german.pestcontrol6?igsh=MXFrazJ5bGlnOXo1ag==";

export function isContactPhone(value: string) {
  // Accept Arabic and Western numerals and common formatting, but require
  // a plausible digit count rather than counting punctuation as digits.
  const digits = value.match(/[0-9٠-٩۰-۹]/gu)?.length ?? 0;
  return /^\+?[0-9٠-٩۰-۹ ()-]+$/u.test(value) && digits >= 10 && digits <= 15;
}
