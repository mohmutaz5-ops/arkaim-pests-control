export const WHATSAPP_NUMBER = "201080808564";

export function openWhatsApp(message?: string) {
  const url = new URL(`https://wa.me/${WHATSAPP_NUMBER}`);
  if (message) url.searchParams.set("text", message);
  window.location.assign(url.toString());
}