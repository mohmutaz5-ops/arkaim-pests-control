import { useSyncExternalStore } from "react";

type Connection = { saveData?: boolean; effectiveType?: string };
type DeviceNavigator = Navigator & { connection?: Connection; deviceMemory?: number };

export function isLowEndDevice() {
  if (typeof navigator === "undefined") return false;
  const device = navigator as DeviceNavigator;
  return Boolean(
    device.connection?.saveData ||
    /(^|-)2g$|^3g$/.test(device.connection?.effectiveType || "") ||
    (device.deviceMemory && device.deviceMemory <= 4),
  );
}

export function initializeDeviceMode() {
  if (isLowEndDevice()) document.documentElement.dataset.lowEnd = "true";
}

const subscribe = () => () => {};
export function useLowEndDevice() {
  return useSyncExternalStore(subscribe, isLowEndDevice, () => false);
}

export function registerStaticCache() {
  if (!import.meta.env.PROD || !("serviceWorker" in navigator)) return;
  window.addEventListener("load", () => {
    // Register without precaching: slow devices only download assets they use.
    void navigator.serviceWorker.register(`${import.meta.env.BASE_URL}sw.js`).catch(console.warn);
  }, { once: true });
}
