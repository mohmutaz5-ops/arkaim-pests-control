import { lazy } from "react";
import { onSectionApproach } from "@/lib/deferred-section";
import { HashNavigation } from "@/components/sections/HashNavigation";
import { Navbar } from "@/components/sections/Navbar";
import { Hero } from "@/components/sections/Hero";
import { TrustStrip } from "@/components/sections/TrustStrip";
import { PestTicker } from "@/components/sections/PestTicker";
import { WhatsAppButton } from "@/components/sections/WhatsAppButton";
import { MobileStickyBar } from "@/components/sections/MobileStickyBar";
import { BackToTop } from "@/components/sections/BackToTop";
import { LazySection } from "@/components/sections/LazySection";

const Services = lazy(() => onSectionApproach("services").then(() => import("@/components/sections/Services")).then(m => ({ default: m.Services })));
// LazySection already waits for proximity or a deep link before mounting these.
const QuickRequestForm = lazy(() => import("@/components/sections/QuickRequestForm").then(m => ({ default: m.QuickRequestForm })));
const Footer = lazy(() => import("@/components/sections/Footer").then(m => ({ default: m.Footer })));
const WhyUs = lazy(() => import("@/components/sections/WhyUs").then(m => ({ default: m.WhyUs })));
const SeasonalOffer = lazy(() => import("@/components/sections/SeasonalOffer").then(m => ({ default: m.SeasonalOffer })));
const HowItWorks = lazy(() => import("@/components/sections/HowItWorks").then(m => ({ default: m.HowItWorks })));
const CoverageAreas = lazy(() => import("@/components/sections/CoverageAreas").then(m => ({ default: m.CoverageAreas })));
const Testimonials = lazy(() => import("@/components/sections/Testimonials").then(m => ({ default: m.Testimonials })));
const ContactForm = lazy(() => import("@/components/sections/ContactForm").then(m => ({ default: m.ContactForm })));

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-background font-sans text-foreground">
      <HashNavigation />
      <Navbar />
      <main className="flex-1 pb-16 md:pb-0">
        <Hero />
        <PestTicker />
        <TrustStrip />
        <LazySection id="services" minHeight={1600} prerender>
          <Services />
        </LazySection>
        <LazySection id="quick-form" minHeight={520}>
          <QuickRequestForm />
        </LazySection>
        <LazySection id="why-us" minHeight={760}>
          <WhyUs />
        </LazySection>
        <LazySection id="offer" minHeight={760}>
          <SeasonalOffer />
        </LazySection>
        <LazySection id="how-it-works" minHeight={460}>
          <HowItWorks />
        </LazySection>
        <LazySection id="coverage" minHeight={560}>
          <CoverageAreas />
        </LazySection>
        <LazySection id="testimonials" minHeight={620}>
          <Testimonials />
        </LazySection>
        <LazySection id="contact" minHeight={760}>
          <ContactForm />
        </LazySection>
      </main>
      <LazySection id="footer" minHeight={360}>
        <Footer />
      </LazySection>
      <WhatsAppButton />
      <BackToTop />
      <MobileStickyBar />
    </div>
  );
}
